import React from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

function App() {
  const resources = [
    { title: "JavaScript Basics", category: "Programming" },
    { title: "DBMS Notes", category: "Computer Science" },
    { title: "Data Structures Guide", category: "DSA" }
  ];

  return (
    <div className="app">
      <header>
        <h1>LearnConnect</h1>
        <p>Share knowledge. Connect with students.</p>
      </header>

      <main>
        <h2>Available Resources</h2>
        <div className="grid">
          {resources.map((resource, index) => (
            <div className="card" key={index}>
              <h3>{resource.title}</h3>
              <p>{resource.category}</p>
              <button>View Resource</button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
