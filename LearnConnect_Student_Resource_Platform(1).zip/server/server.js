const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    message: "Welcome to LearnConnect API",
    status: "Server is running successfully"
  });
});

app.get("/api/resources", (req, res) => {
  res.json([
    {
      id: 1,
      title: "JavaScript Basics",
      category: "Programming",
      sharedBy: "Student"
    },
    {
      id: 2,
      title: "DBMS Notes",
      category: "Computer Science",
      sharedBy: "Student"
    }
  ]);
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
