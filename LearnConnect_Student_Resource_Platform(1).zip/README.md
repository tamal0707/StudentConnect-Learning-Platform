# LearnConnect - Student Resource Platform

A full-stack learning platform where students can share educational resources and connect with other learners.

## Tech Stack
- React.js
- Node.js
- Express.js
- MongoDB

## How to run
1. Install Node.js.
2. Open the `server` folder and run `npm install`, then `npm start`.
3. Open the `client` folder and run `npm install`, then `npm start`.

This is a starter project structure for GitHub.
